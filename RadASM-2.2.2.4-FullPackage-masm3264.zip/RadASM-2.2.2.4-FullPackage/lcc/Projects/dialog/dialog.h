
typedef struct {
 UINT idLength;
 UINT * ids;
} AsnObjectIdentifier;

